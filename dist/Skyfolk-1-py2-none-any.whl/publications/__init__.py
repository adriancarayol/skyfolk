default_app_config = 'publications.apps.PublicationAppConfig'
